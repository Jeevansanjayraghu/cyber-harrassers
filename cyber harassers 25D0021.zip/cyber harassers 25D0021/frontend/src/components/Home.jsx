import React, { useState } from "react";
import axios from "axios";
import { FaRobot } from "react-icons/fa";
import { BsFillSendFill } from "react-icons/bs";
import { AiOutlineLogout } from "react-icons/ai";
import "./WhatsAppChat.css"; // Import the external CSS
import { useNavigate } from "react-router-dom";

const WhatsAppChat = () => {
  const [messages, setMessages] = useState([]);
  const [input, setInput] = useState("");
  const navigate = useNavigate(); // Initialize useNavigate

  // Function to handle sending messages
  const handleSendMessage = async () => {
    if (input.trim() === "") return; // Prevent sending empty messages

    // Add user message to the chat
    const userMessage = { sender: "user", text: input };
    setMessages((prevMessages) => [...prevMessages, userMessage]);

    try {
      // Send input to the Flask API
      const response = await axios.post("http://127.0.0.1:5000/predict", {
        tweet: input,
        hate_speech: 0,
        offensive_language: 0,
        neither: 0,
      });

      const predictedClass = response.data.predicted_class;

      if (predictedClass === 2) {
        // Add bot's response to the chat if the prediction is not offensive
        const botMessage = { sender: "bot", text: "This text is safe and not offensive." };
        setMessages((prevMessages) => [...prevMessages, botMessage]);
      } else {
        // Show alert if the message is offensive
        alert("The text is considered offensive. Please be cautious.");
        // Remove the last user message from the chat
        setMessages((prevMessages) => prevMessages.slice(0, -1));
      }
    } catch (error) {
      console.error("Error sending message:", error);
      const errorMessage = {
        sender: "bot",
        text: "Failed to send message. Please try again.",
      };
      setMessages((prevMessages) => [...prevMessages, errorMessage]);
    }

    setInput(""); // Clear the input field
  };

  // Function to handle logout
  const handleLogout = () => {
    localStorage.removeItem("token");
    localStorage.removeItem("userEmail");
    navigate("/"); // Navigate to the default page
  };

  return (
    <div className="main">
      {/* Header */}
      <div className="header">
        <div className="logo">
          <FaRobot className="robot-icon" />
          <span className="title">Cyber Harassers</span>
        </div>
        <button onClick={handleLogout} className="logout-button">
          <AiOutlineLogout className="text-xl mr-2" />
          Logout
        </button>
      </div>

      {/* Chat Messages */}
      <div className="chat-container">
        {messages.map((message, index) => (
          <div
            key={index}
            className={`chat-message ${
              message.sender === "user" ? "user" : "bot"
            }`}
          >
            <div className="message">{message.text}</div>
          </div>
        ))}
      </div>

      {/* Input Area */}
      <div className="input-area">
        <input
          type="text"
          value={input}
          onChange={(e) => setInput(e.target.value)}
          placeholder="Type a message..."
        />
        <button onClick={handleSendMessage}>
          <BsFillSendFill className="text-xl" />
        </button>
      </div>
    </div>
  );
};

export default WhatsAppChat;
