from flask import Flask, request, jsonify
import joblib
import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from scipy.sparse import hstack
import string
from flask_cors import CORS  # Import CORS
import numpy as np

app = Flask(__name__)
CORS(app)  # Enable CORS for all routes

# Load the model
model = joblib.load(r'C:\Users\Public\acdemic\cyber harassers 25D0021\flask\model.pkl')

# Load the vectorizer used for text transformation
vectorizer = joblib.load(r'C:\Users\Public\acdemic\cyber harassers 25D0021\flask\vectorizer.pkl')

# Define the feature extraction function
def preprocess_text(text):
    text = text.lower()
    text = text.translate(str.maketrans('', '', string.punctuation))
    text = text.strip()
    return text

def predict_class(tweet, hate_speech, offensive_language, neither):
    # Preprocess the text
    tweet = preprocess_text(tweet)
    
    # Vectorize the text
    tweet_vectorized = vectorizer.transform([tweet])
    
    # Combine text features and numerical features
    numeric_features = [hate_speech, offensive_language, neither]
    X_combined = hstack([tweet_vectorized, pd.DataFrame([numeric_features])])
    
    # Make prediction
    prediction = model.predict(X_combined)
    return prediction[0]

@app.route('/predict', methods=['POST'])
def predict():
    try:
        # Get JSON data from the request
        data = request.json
        
        # Extract inputs from the request
        tweet = data.get('tweet', '')
        hate_speech = data.get('hate_speech', 0)
        offensive_language = data.get('offensive_language', 0)
        neither = data.get('neither', 0)

        # Ensure numerical inputs are integers
        hate_speech = int(hate_speech)
        offensive_language = int(offensive_language)
        neither = int(neither)

        # Predict class
        result = predict_class(tweet, hate_speech, offensive_language, neither)

        # Convert result to Python-native type
        if isinstance(result, (pd.Series, pd.DataFrame, np.int64, np.float64)):
            result = result.item()  # Convert to a standard Python scalar type (e.g., int)

        # Return result as JSON
        return jsonify({"predicted_class": result})

    except Exception as e:
        return jsonify({"error": str(e)})

if __name__ == '__main__':
    app.run(debug=True)
